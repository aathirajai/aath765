package Login;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;



import io.github.bonigarcia.wdm.WebDriverManager;



public class Salesforceogin {



public static void main(String[] args) throws InterruptedException {
// TODO Auto-generated method stub


WebDriverManager.chromedriver().setup();
ChromeOptions options = new ChromeOptions();
options.addArguments("--disable-notifications");
ChromeDriver driver = new ChromeDriver(options);

driver.manage().window().maximize();


//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.get("https://login.salesforce.com/");
driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
driver.findElement(By.id("password")).sendKeys("Tuna@123");
driver.findElement(By.id("Login")).click();
driver.findElement(By.xpath("//lightning-primitive-icon/*[@class='slds-icon slds-icon_x-small']")).click();

Thread.sleep(10000);


}



}



